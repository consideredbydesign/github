# Disappearing pen

A Pen created on CodePen.io. Original URL: [https://codepen.io/johnellosit/pen/eYPrrWj](https://codepen.io/johnellosit/pen/eYPrrWj).

